<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
<form action="<?php echo e(route('spending.store')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <h2>Thêm </h2>

    



    <div class="form-group">
            <label for="danhmuc">Danh mục</label>
            <select class="form-control <?php $__errorArgs = ['danhmuc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="danhmuc" id="danhmuc">
                <option value="" selected disabled>--Chọn danh mục--</option>
                <option value="Ăn" <?php echo e(old('danhmuc') == 'ga' ? 'selected' : ''); ?>>Ăn</option>
                <option value="Thuốc" <?php echo e(old('danhmuc') == 'điện' ? 'selected' : ''); ?>>Thuốc</option>
                <option value="Nước" <?php echo e(old('danhmuc') == 'nước' ? 'selected' : ''); ?>>Nước</option>
            </select>
            <?php $__errorArgs = ['danhmuc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="alert alert-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>



    <div class="mb-3">
        <label for="ngay" class="form-label">Ngày</label>
        <input type="date" class="form-control" name="ngay" id="ngay" value="<?php echo e(old('ngay')); ?>">
        <?php $__errorArgs = ['ngay'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="alert alert-danger"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="mb-3">
        <label for="sotien" class="form-label">Số tiền</label>
        <input type="text" class="form-control" name="sotien" id="sotien" value="<?php echo e(old('sotien')); ?>">
        <?php $__errorArgs = ['sotien'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="alert alert-danger"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="mb-3">
        <label for="note" class="form-label">Ghi chú</label>
        <input type="text" class="form-control" name="note" id="note" value="<?php echo e(old('note')); ?>">
        <?php $__errorArgs = ['note'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="alert alert-danger"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <button type="submit" class="btn btn-primary">Thêm</button>
    <a href="<?php echo e(route('spending.index')); ?>">Quay lại</a>
</form>
<?php /**PATH D:\laragon\www\M4\Thi_Thuc_Hanh_M4\resources\views/spendings/create.blade.php ENDPATH**/ ?>