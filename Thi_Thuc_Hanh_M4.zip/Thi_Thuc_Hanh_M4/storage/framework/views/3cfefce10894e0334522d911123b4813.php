<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous">
</script>
<div class="container">

    
<table border="1" class="table" style="text-align:center">
    <h1>Danh sách chi tiêu</h1>
    <div class="col-lg-6 col-md-5 col-sm-4 hidden-xs">
        <!-- Search -->
        <div class="search_box">
            <div class="search_wrapper">


            <form class="form-inline my-2 my-lg-0" action="<?php echo e(route('spending.index')); ?>" method="GET">
    <div class="input-group">
        <input class="form-control" name="search" type="text" placeholder="Tìm kiếm">
        <button class="btn btn-success" type="submit">Tìm kiếm</button>
    </div>
</form>



            </div>
        </div>
        <!-- End Search -->
    </div>
    <a href="<?php echo e(route('spending.create')); ?>" class="btn btn-info">Thêm chi tiêu</a>
    <thead>
        <tr>
            <th>STT</th>
            <th>Danh mục</th>
            <th>Ngày</th>
            <th>Số Tiền(VNĐ)</th>
            <th>Hành Động</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $spendings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $spending): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e(++$key); ?></td>
            <td><?php echo e($spending->danhmuc); ?></td>
            <td><?php echo e($spending->ngay); ?></td>
            <td><?php echo e($spending->sotien); ?></td>

            <td>
                <form action="<?php echo e(route('spending.destroy',[$spending->id])); ?>" method="post">
                    <?php echo method_field('DELETE'); ?>
                    <?php echo csrf_field(); ?>
                    <a href="<?php echo e(route('spending.edit',[$spending->id])); ?>" class="btn btn-warning">Sửa</a>
                    <button onclick="return confirm('Bạn có chắc chắn muốn xóa không?');"
                        class="btn btn-danger">Xóa</button>
                </form>
            </td>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tr>
    </tbody>

</table>
<div class="text-end">
        <h5>Tổng tiền chi tiêu: <span class="text-dark"><?php echo e($totalAmount); ?> VND</span></h5>
    </div>

<a class="btn btn-primary" href="<?php echo e(route('spending.index')); ?>">Trang chủ</a>
<div class="d-flex justify-content-end">
        <?php echo e($spendings->appends(request()->query())); ?>

    </div>

</div><?php /**PATH D:\laragon\www\M4\Thi_Thuc_Hanh_M4\resources\views/spendings/index.blade.php ENDPATH**/ ?>